package com.infy.model;

import java.util.List;
import java.util.Scanner;

import org.hibernate.*;






public class Admin 
{
	Scanner sc = new Scanner(System.in);
	HibernateUtil hiber = new HibernateUtil();
	
	

	void showOptions()
	{
	
		SessionFactory sFactory = HibernateUtil.getSessionFactory();
		Session sess= sFactory.openSession();
		Transaction tx= sess.beginTransaction();
		
		Query query=sess.createQuery("from Item");
		@SuppressWarnings("unchecked")
		List<Item> item =query.list();
		
		for(Item i:item)
		{
			System.out.println(i.toString());
		}
		
		tx.commit();
		sess.close();
		sFactory.close();
		
	}
	
	void addItem(int id,String name,int price)
	{
		
		SessionFactory sFactory = HibernateUtil.getSessionFactory();
		Session sess= sFactory.openSession();
		Transaction tx= sess.beginTransaction();
		
		//Adding an item into database
		
		Item item = new Item(id,name,price);
		sess.save(item);
		System.out.println("Added succesfully");
		

		tx.commit();
		sess.close();
		sFactory.close();
		
		
	}
	void updateItem(int id)
	{
		int choice,price;
		String name;
		SessionFactory sFactory = HibernateUtil.getSessionFactory();
		Session sess= sFactory.openSession();
		Transaction tx= sess.beginTransaction();
		
		//Adding an item into database
		
		Item emp2 =(Item) sess.load(Item.class, id);
		System.out.println("The Item is:"+ emp2.getItemName());
		System.out.println("Press 1 to update name or 2 to update price");
		choice=sc.nextInt();
		if(choice==1)
		{
			System.out.println("Enter name");
			name=sc.next();
			emp2.setItemName(name);
			
		}
		else if(choice ==2)
		{
			System.out.println("Enter price");
			price=sc.nextInt();
			emp2.setItemPrice(price);
		}
		else
			System.out.println("Wrong Choice");
		

		tx.commit();
		sess.close();
		sFactory.close();
	}

	void deleteItem(int id)
	{
		SessionFactory sFactory = HibernateUtil.getSessionFactory();
		Session sess= sFactory.openSession();
		Transaction tx= sess.beginTransaction();
		Item emp2 =(Item) sess.get(Item.class, id);
		
		
		System.out.println("The item "+ emp2.getItemName()+ " is deleted");
		sess.delete(emp2);
		tx.commit();
		sess.close();
		sFactory.close();
		
	}
	
	void searchItem(int id)
	{
		SessionFactory sFactory = HibernateUtil.getSessionFactory();
		Session sess= sFactory.openSession();
		Transaction tx= sess.beginTransaction();
		
		//Adding an item into database
		
		Item emp2 =(Item) sess.load(Item.class, id);
		System.out.println("The Item Name is:"+ emp2.getItemName());
		

		tx.commit();
		sess.close();
		sFactory.close();
		
	}
	
	
}
