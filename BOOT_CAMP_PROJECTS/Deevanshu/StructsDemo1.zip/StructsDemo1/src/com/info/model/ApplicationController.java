package com.info.model;

public class ApplicationController 
{

	public String execute()
	{
		return "success";
	}
	
}
